import { useState } from 'react';
import { BorrowForm } from './components/BorrowForm';
import { ReturnForm } from './components/ReturnForm';
import { ActiveLoans } from './components/ActiveLoans';
import { LoanHistory } from './components/LoanHistory';
import { Laptop } from 'lucide-react';

export interface LoanRecord {
  id: string;
  studentId: string;
  nama: string;
  kelas: string;
  laptopId: string;
  borrowTimestamp: Date;
  returnTimestamp?: Date;
  status: 'dipinjam' | 'dikembalikan';
}

export default function App() {
  const [loans, setLoans] = useState<LoanRecord[]>([]);
  const [activeTab, setActiveTab] = useState<'borrow' | 'return' | 'active' | 'history'>('borrow');

  const handleBorrow = (data: { studentId: string; nama: string; kelas: string; laptopId: string }) => {
    const newLoan: LoanRecord = {
      id: Date.now().toString(),
      ...data,
      borrowTimestamp: new Date(),
      status: 'dipinjam',
    };
    setLoans([...loans, newLoan]);
  };

  const handleReturn = (loanId: string) => {
    setLoans(loans.map(loan => 
      loan.id === loanId 
        ? { ...loan, returnTimestamp: new Date(), status: 'dikembalikan' as const }
        : loan
    ));
  };

  const activeLoans = loans.filter(loan => loan.status === 'dipinjam');
  const loanHistory = loans.filter(loan => loan.status === 'dikembalikan');

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 py-6">
          <div className="flex items-center gap-3">
            <Laptop className="w-8 h-8 text-blue-600" />
            <h1>Sistem Peminjaman Laptop</h1>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 py-8">
        <div className="bg-white rounded-lg shadow-sm mb-6">
          <div className="flex border-b">
            <button
              onClick={() => setActiveTab('borrow')}
              className={`px-6 py-3 transition-colors ${
                activeTab === 'borrow'
                  ? 'border-b-2 border-blue-600 text-blue-600'
                  : 'text-gray-600 hover:text-gray-900'
              }`}
            >
              Peminjaman
            </button>
            <button
              onClick={() => setActiveTab('return')}
              className={`px-6 py-3 transition-colors ${
                activeTab === 'return'
                  ? 'border-b-2 border-blue-600 text-blue-600'
                  : 'text-gray-600 hover:text-gray-900'
              }`}
            >
              Pengembalian
            </button>
            <button
              onClick={() => setActiveTab('active')}
              className={`px-6 py-3 transition-colors ${
                activeTab === 'active'
                  ? 'border-b-2 border-blue-600 text-blue-600'
                  : 'text-gray-600 hover:text-gray-900'
              }`}
            >
              Laptop Dipinjam ({activeLoans.length})
            </button>
            <button
              onClick={() => setActiveTab('history')}
              className={`px-6 py-3 transition-colors ${
                activeTab === 'history'
                  ? 'border-b-2 border-blue-600 text-blue-600'
                  : 'text-gray-600 hover:text-gray-900'
              }`}
            >
              Riwayat
            </button>
          </div>

          <div className="p-6">
            {activeTab === 'borrow' && <BorrowForm onSubmit={handleBorrow} />}
            {activeTab === 'return' && <ReturnForm loans={activeLoans} onReturn={handleReturn} />}
            {activeTab === 'active' && <ActiveLoans loans={activeLoans} />}
            {activeTab === 'history' && <LoanHistory loans={loanHistory} />}
          </div>
        </div>
      </main>
    </div>
  );
}
