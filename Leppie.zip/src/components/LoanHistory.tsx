import { LoanRecord } from '../App';
import { Clock, CheckCircle } from 'lucide-react';

interface LoanHistoryProps {
  loans: LoanRecord[];
}

export function LoanHistory({ loans }: LoanHistoryProps) {
  if (loans.length === 0) {
    return (
      <div className="text-center py-12 text-gray-500">
        <p>Belum ada riwayat pengembalian</p>
      </div>
    );
  }

  return (
    <div className="overflow-x-auto">
      <table className="w-full">
        <thead>
          <tr className="border-b border-gray-200">
            <th className="text-left py-3 px-4 text-gray-700">ID Siswa</th>
            <th className="text-left py-3 px-4 text-gray-700">Nama</th>
            <th className="text-left py-3 px-4 text-gray-700">Kelas</th>
            <th className="text-left py-3 px-4 text-gray-700">ID Laptop</th>
            <th className="text-left py-3 px-4 text-gray-700">Waktu Peminjaman</th>
            <th className="text-left py-3 px-4 text-gray-700">Waktu Pengembalian</th>
          </tr>
        </thead>
        <tbody>
          {loans.map((loan) => (
            <tr key={loan.id} className="border-b border-gray-100 hover:bg-gray-50">
              <td className="py-3 px-4">{loan.studentId}</td>
              <td className="py-3 px-4">{loan.nama}</td>
              <td className="py-3 px-4">{loan.kelas}</td>
              <td className="py-3 px-4">
                <span className="bg-gray-100 text-gray-800 px-3 py-1 rounded">
                  {loan.laptopId}
                </span>
              </td>
              <td className="py-3 px-4">
                <div className="flex items-center gap-2 text-gray-600">
                  <Clock className="w-4 h-4" />
                  {loan.borrowTimestamp.toLocaleString('id-ID')}
                </div>
              </td>
              <td className="py-3 px-4">
                {loan.returnTimestamp && (
                  <div className="flex items-center gap-2 text-green-600">
                    <CheckCircle className="w-4 h-4" />
                    {loan.returnTimestamp.toLocaleString('id-ID')}
                  </div>
                )}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
