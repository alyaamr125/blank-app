import { useState } from 'react';
import { CheckCircle, Search } from 'lucide-react';
import { LoanRecord } from '../App';

interface ReturnFormProps {
  loans: LoanRecord[];
  onReturn: (loanId: string) => void;
}

export function ReturnForm({ loans, onReturn }: ReturnFormProps) {
  const [searchTerm, setSearchTerm] = useState('');

  const filteredLoans = loans.filter(
    loan =>
      loan.studentId.toLowerCase().includes(searchTerm.toLowerCase()) ||
      loan.nama.toLowerCase().includes(searchTerm.toLowerCase()) ||
      loan.laptopId.toLowerCase().includes(searchTerm.toLowerCase())
  );

  if (loans.length === 0) {
    return (
      <div className="text-center py-12 text-gray-500">
        <p>Tidak ada laptop yang sedang dipinjam</p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="relative">
        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
        <input
          type="text"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          placeholder="Cari berdasarkan ID siswa, nama, atau ID laptop..."
        />
      </div>

      <div className="space-y-3">
        {filteredLoans.map(loan => (
          <div
            key={loan.id}
            className="flex items-center justify-between p-4 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors"
          >
            <div className="flex-1">
              <div className="flex items-center gap-4 mb-2">
                <span className="bg-blue-100 text-blue-800 px-3 py-1 rounded">
                  {loan.laptopId}
                </span>
                <span className="text-gray-600">ID: {loan.studentId}</span>
              </div>
              <p>{loan.nama}</p>
              <p className="text-gray-600">Kelas: {loan.kelas}</p>
              <p className="text-gray-500">
                Dipinjam: {loan.borrowTimestamp.toLocaleString('id-ID')}
              </p>
            </div>
            <button
              onClick={() => onReturn(loan.id)}
              className="bg-green-600 text-white px-6 py-2 rounded-lg hover:bg-green-700 transition-colors flex items-center gap-2"
            >
              <CheckCircle className="w-5 h-5" />
              Kembalikan
            </button>
          </div>
        ))}
      </div>

      {filteredLoans.length === 0 && searchTerm && (
        <div className="text-center py-8 text-gray-500">
          <p>Tidak ditemukan hasil untuk "{searchTerm}"</p>
        </div>
      )}
    </div>
  );
}
