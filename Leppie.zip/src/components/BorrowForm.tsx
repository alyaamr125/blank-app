import { useState } from 'react';
import { UserCircle, BookOpen, Laptop, Calendar } from 'lucide-react';

interface BorrowFormProps {
  onSubmit: (data: { studentId: string; nama: string; kelas: string; laptopId: string }) => void;
}

export function BorrowForm({ onSubmit }: BorrowFormProps) {
  const [formData, setFormData] = useState({
    studentId: '',
    nama: '',
    kelas: '',
    laptopId: '',
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (formData.studentId && formData.nama && formData.kelas && formData.laptopId) {
      onSubmit(formData);
      setFormData({ studentId: '', nama: '', kelas: '', laptopId: '' });
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div>
        <label className="block text-gray-700 mb-2">
          <div className="flex items-center gap-2 mb-2">
            <UserCircle className="w-5 h-5" />
            <span>ID Siswa</span>
          </div>
          <input
            type="text"
            value={formData.studentId}
            onChange={(e) => setFormData({ ...formData, studentId: e.target.value })}
            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            placeholder="Masukkan ID siswa"
            required
          />
        </label>
      </div>

      <div>
        <label className="block text-gray-700 mb-2">
          <div className="flex items-center gap-2 mb-2">
            <UserCircle className="w-5 h-5" />
            <span>Nama</span>
          </div>
          <input
            type="text"
            value={formData.nama}
            onChange={(e) => setFormData({ ...formData, nama: e.target.value })}
            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            placeholder="Masukkan nama siswa"
            required
          />
        </label>
      </div>

      <div>
        <label className="block text-gray-700 mb-2">
          <div className="flex items-center gap-2 mb-2">
            <BookOpen className="w-5 h-5" />
            <span>Kelas</span>
          </div>
          <input
            type="text"
            value={formData.kelas}
            onChange={(e) => setFormData({ ...formData, kelas: e.target.value })}
            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            placeholder="Masukkan kelas (contoh: 10A, 11B)"
            required
          />
        </label>
      </div>

      <div>
        <label className="block text-gray-700 mb-2">
          <div className="flex items-center gap-2 mb-2">
            <Laptop className="w-5 h-5" />
            <span>ID Laptop</span>
          </div>
          <input
            type="text"
            value={formData.laptopId}
            onChange={(e) => setFormData({ ...formData, laptopId: e.target.value })}
            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            placeholder="Masukkan ID laptop"
            required
          />
        </label>
      </div>

      <button
        type="submit"
        className="w-full bg-blue-600 text-white py-3 rounded-lg hover:bg-blue-700 transition-colors flex items-center justify-center gap-2"
      >
        <Calendar className="w-5 h-5" />
        Catat Peminjaman
      </button>
    </form>
  );
}
